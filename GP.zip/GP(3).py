# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 12:05:25 2025

@author: msipc
"""

import random
def common(lst):
    lst.sort()
    for i in range(len(lst) - 1):
        if lst[i] == lst[i + 1]:
            return 1
    return 0

Challenge = 0

X_list = []
Y_list = []
Chess = int(input("how many chess"))


for N in range(100000):
    for j in range(Chess):
         
        x = random.randrange(1, 9, 1)
        y = random.randrange(1, 9, 1)
        X_list.append(x)
        Y_list.append(y)
        
   
    a = common(X_list)
    b = common(Y_list)
    

            
    
    if a == 1 or b == 1:
        Challenge = Challenge + 1
    
    X_list.clear()
    Y_list.clear()
    

print(1 - Challenge/N)