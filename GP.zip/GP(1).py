# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 12:04:13 2025

@author: msipc
"""

import random
Challenge = 0

for N in range(10000):
    
    
    (a , b) = (random.randrange(1,9,1),random.randrange(1,9,1))
    (c , d) = (random.randrange(1,9,1),random.randrange(1,9,1))
    
    if a == c or b == d:
        Challenge = Challenge + 1

print(1 - Challenge / 10000)